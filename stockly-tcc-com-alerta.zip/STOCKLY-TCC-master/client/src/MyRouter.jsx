import { createBrowserRouter } from "react-router-dom";

import App from "./App.jsx";
import PaginaErro from "./pages/PaginaErro.jsx";
import Login from "./pages/Login.jsx";
import RotasProtegidas from "./pages/RotasProtegidas.jsx";
import Home from "./pages/Home.jsx";


// Páginas de produto
import VerProdutos from "./pages/Produtos/VerProdutos.jsx";
import CadastrarProduto from "./pages/Produtos/CadastrarProduto.jsx";
import EditarProduto from "./pages/Produtos/EditarProduto.jsx";

// Páginas de funcionário
import VerFuncionarios from "./pages/Funcionario/VerFuncionarios.jsx";
import CadastrarFuncionario from "./pages/Funcionario/CadastrarFuncionario.jsx";
import EditarFuncionario from "./pages/Funcionario/EditarFuncionario.jsx";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <PaginaErro />,
    children: [
      { index: true, element: <Login /> },
      { path: "login", element: <Login /> },
    ],
  },
  {
    path: "/",
    element: <RotasProtegidas />,
    errorElement: <PaginaErro />,
    children: [
      { path: "home", element: <Home /> },

      // Rotas de produtos
      {
        path: "produtos",
        children: [
          { index: true, element: <VerProdutos /> },
          { path: "cadastrar", element: <CadastrarProduto /> },
          { path: "editar/:id", element: <EditarProduto /> },
        ],
      },

      // Rotas de funcionários
      {
        path: "funcionarios",
        children: [
          { index: true, element: <VerFuncionarios /> },
          { path: "cadastrar", element: <CadastrarFuncionario /> },
          { path: "editar/:id", element: <EditarFuncionario /> },
        ],
      },
    ],
  },
]);

export default router;
