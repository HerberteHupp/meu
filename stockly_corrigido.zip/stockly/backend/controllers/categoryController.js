const pool = require('../db');

// Obter todas as categorias
exports.getAllCategories = async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM categorias');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Erro ao obter categorias:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter categoria por ID
exports.getCategoryById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).json({ message: 'Categoria não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao obter categoria por ID:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Criar nova categoria
exports.createCategory = async (req, res) => {
    const { nome } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO categorias (nome) VALUES (?)',
            [nome]
        );
        res.status(201).json({ id: result.insertId, nome });
    } catch (error) {
        console.error('Erro ao criar categoria:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Atualizar categoria
exports.updateCategory = async (req, res) => {
    const { id } = req.params;
    const { nome } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE categorias SET nome = ? WHERE id = ?',
            [nome, id]
        );
        if (result.affectedRows > 0) {
            res.status(200).json({ id, nome });
        } else {
            res.status(404).json({ message: 'Categoria não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao atualizar categoria:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Deletar categoria
exports.deleteCategory = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM categorias WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Categoria não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao deletar categoria:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};
