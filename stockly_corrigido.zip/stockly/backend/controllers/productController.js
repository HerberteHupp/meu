const pool = require('../db');

// Obter todos os produtos
exports.getAllProducts = async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT 
                p.id, p.nome, p.descricao, p.preco, p.quantidade, 
                c.nome AS categoria_nome, p.categoria_id
            FROM produtos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error('Erro ao obter produtos:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter produto por ID
exports.getProductById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query(`
            SELECT 
                p.id, p.nome, p.descricao, p.preco, p.quantidade, 
                c.nome AS categoria_nome, p.categoria_id
            FROM produtos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
            WHERE p.id = ?
        `, [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter produto por ID:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Criar novo produto
exports.createProduct = async (req, res) => {
    const { nome, descricao, preco, quantidade, categoria_id } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO produtos (nome, descricao, preco, quantidade, categoria_id) VALUES (?, ?, ?, ?, ?)',
            [nome, descricao, preco, quantidade, categoria_id]
        );
        res.status(201).json({ id: result.insertId, nome, descricao, preco, quantidade, categoria_id });
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Atualizar produto
exports.updateProduct = async (req, res) => {
    const { id } = req.params;
    const { nome, descricao, preco, quantidade, categoria_id } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE produtos SET nome = ?, descricao = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?',
            [nome, descricao, preco, quantidade, categoria_id, id]
        );
        if (result.affectedRows > 0) {
            res.status(200).json({ id, nome, descricao, preco, quantidade, categoria_id });
        } else {
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar produto:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Deletar produto
exports.deleteProduct = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM produtos WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar produto:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};
