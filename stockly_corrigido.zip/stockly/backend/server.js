const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors()); // Permite requisições de diferentes origens (necessário para o frontend React)
app.use(express.json()); // Permite que o servidor entenda JSON no corpo da requisição

// Rotas
const userRoutes = require('./routes/userRoutes');
const productRoutes = require('./routes/productRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const departmentRoutes = require('./routes/departmentRoutes');

app.use('/api/usuarios', userRoutes);
app.use('/api/produtos', productRoutes);
app.use('/api/funcionarios', employeeRoutes);
app.use('/api/categorias', categoryRoutes);
app.use('/api/departamentos', departmentRoutes);

// Rota de teste
app.get('/', (req, res) => {
    res.send('Backend Stockly está rodando!');
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
