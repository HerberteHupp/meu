function Home() {
  
  return (
    <div>
      <h1>HOME</h1>
    </div>
  );
}

export default Home;
